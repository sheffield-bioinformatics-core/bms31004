if(!require(BiocManager)) install.packages("BiocManager")
BiocManager::install(c("limma", 
         "org.Hs.eg.db", 
         "RColorBrewer", 
         "DESeq2",
         "pheatmap",
         "rmarkdown",
         "tximport",
         "clusterProfiler",
         "DOSE",
         "biomaRt",
         "dplyr",
         "ggplot2"),suppressUpdates=TRUE)
